# Elevate Internship Task 1 – Full Output
This folder contains all final deliverables.